	$(function(){
		$('.chart').easyPieChart({
			size:150,
			barColor:'#17c2a4',
			scaleColor:false,
			lineWidth :10,
			lineCap:'circle',
			animate:2000


		})
	})