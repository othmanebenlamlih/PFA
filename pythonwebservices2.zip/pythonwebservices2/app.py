from flask import Flask , send_file,flash,request, redirect, url_for, render_template ,jsonify ,request
from skimage import img_as_float
import skimage.metrics
from skimage.metrics import peak_signal_noise_ratio#im importing peak_signal_noise_ratio that is in skimage.metric and im gonna use this to report the between my noisy image and the cleaned image 
from matplotlib import pyplot as plt
from skimage import io
from scipy import ndimage as nd  #now im gone to use gaussian filter that's part of scifi package
import os
from medpy.filter.smoothing import anisotropic_diffusion
from skimage.restoration import (denoise_tv_chambolle, denoise_bilateral,denoise_wavelet, estimate_sigma)
from medpy.filter.smoothing import anisotropic_diffusion
import random
from random import randint
import bm3d

app = Flask(__name__) #create server



@app.route("/")
def welcome():
    return render_template('index.html')


@app.route("/Gaussian",methods=['POST'])
def Gaussian():

    if request.method == 'POST':
        #image = request.files['image']
    
        #recuperer image 
        image = request.files["image"]
        #recuperer les parametre
        sigma = float(request.values["sigma"])
        #chemin d'image
        filename = request.files["image"].filename
        #enregistrer image bruite
        image.save(os.path.join("static/img/", filename))
        #recuperer l'image
        noisy_img = img_as_float(io.imread("static/img/"+filename))

        #filtrer l'image
        gaussian_img = nd.gaussian_filter(noisy_img, sigma=sigma)
        #calculer psnr                                                                                       
        noise_psnr = peak_signal_noise_ratio(gaussian_img, noisy_img)
        #enregistrer image filtrer
        nbr=str(random.randint(1, 10000))
        randomImageName = "image"+nbr+".jpg"
        plt.imsave("static/img/"+randomImageName, gaussian_img)
        ####
        filename = "static/img/"+filename    
    return render_template('result.html', message ="Gaussian" , noisy = str(noise_psnr), att = str(sigma) , image =str(filename), filename=randomImageName, srcc="static/img/"+randomImageName)#, message ="Gaussian" , noisy = str(noise_psnr), att = str(sigma) , image =str(filename), filename=randomImageName
    #return str(noise_psnr)

"""
@app.route("/Bilateral",methods=['POST'])
def Bilateral():
    #recuperer image 
    image = request.files["image"]
    #recuperer les parametre
    sigma_sp = float(request.values["sigma-sp"])
    selectOptionColor = str(request.values["selectOptionColor"])
    #chemin d'image
    filename = request.files["image"].filename
    #enregistrer image bruite
    image.save(os.path.join("E:/S3/PFE/static/", filename))
    #recuperer l'image
    noisy_img = img_as_float(io.imread("E:/S3/PFE/static/"+filename))
    #filtrer l'image
    Bilateral_img = denoise_bilateral(noisy_img, sigma_spatial=sigma_sp,multichannel=selectOptionColor)#multichannel = black and white or rgb
    #calculer psnr                                                                                       
    noise_psnr = peak_signal_noise_ratio(Bilateral_img, noisy_img)
    #enregistrer image filtrer
    nbr=str(random.randint(1, 10000))
    randomImageName = "image"+nbr+".jpg"
    plt.imsave("E:/S3/PFE/static/"+randomImageName, Bilateral_img, cmap='gray')
    ####
    return render_template('result.html', message ="Bilateral" , noisy = str(noise_psnr), att = str(sigma_sp)+selectOptionColor, filename=randomImageName)
    #return str(noise_psnr)

@app.route("/Wavelet",methods=['POST'])
def Wavelet():
    #recuperer image 
    image = request.files["image"]
    #recuperer les parametre
    selectOption = str(request.values["selectOption"])
    selectOptionColor = request.values["selectOptionColor"]
    #chemin d'image
    filename = request.files["image"].filename
    #enregistrer image bruite
    image.save(os.path.join("E:/S3/PFE/static/", filename))
    #recuperer l'image
    noisy_img = img_as_float(io.imread("E:/S3/PFE/static/"+filename))
    #filtrer l'image
    Wavelet_img = denoise_wavelet(noisy_img, multichannel=selectOptionColor,method=selectOption, mode='soft',rescale_sigma=True)
    #calculer psnr                                                                                       
    noise_psnr = peak_signal_noise_ratio(Wavelet_img, noisy_img)
    #enregistrer image filtrer
    nbr=str(random.randint(1, 10000))
    randomImageName = "image"+nbr+".jpg"
    plt.imsave("E:/S3/PFE/static/"+randomImageName, Wavelet_img, cmap='gray')
    ####
    return render_template('result.html', message ="Wavelet" , noisy = str(noise_psnr), att = selectOption+selectOptionColor, filename=randomImageName)
    #return str(noise_psnr)

@app.route("/Anisotropic_Diffusion",methods=['POST'])
def Anisotropic_Diffusion():
    #recuperer image 
    image = request.files["image"]
    #recuperer les parametre
    niter = int(request.values["niter"])
    kappa = int(request.values["kappa"])
    gamma = 0.1
    #chemin d'image
    filename = request.files["image"].filename
    #enregistrer image bruite
    image.save(os.path.join("E:/S3/PFE/static/", filename))
    #recuperer l'image
    noisy_img = img_as_float(io.imread("E:/S3/PFE/static/"+filename))
    #filtrer l'image
    Anisotropic_Diffusion_img = anisotropic_diffusion(noisy_img, niter=niter, kappa=kappa, gamma=gamma, option=2) 
    #calculer psnr                                                                                       
    noise_psnr = peak_signal_noise_ratio(Anisotropic_Diffusion_img, noisy_img)
    #enregistrer image filtrer
    nbr=str(random.randint(1, 10000))
    randomImageName = "image"+nbr+".jpg"
    plt.imsave("E:/S3/PFE/static/"+randomImageName, Anisotropic_Diffusion_img, cmap='gray')
    ####
    #info = " niter "+niter+" kappa "+kappa+" gamma "
    return render_template('result.html', message ="Anisotropic Diffusion" , noisy = str(noise_psnr) , filename=randomImageName)
    #return str(noise_psnr)


@app.route("/BM3D_Block_matching_and_3D_filtering",methods=['POST'])
def BM3D_Block_matching_and_3D_filtering():
    
    #recuperer image 
    image = request.files["image"]
    #recuperer les parametre
    sigma = float(request.values["sigma-psd"])
    #chemin d'image
    filename = request.files["image"].filename
    #enregistrer image bruite
    image.save(os.path.join("E:/S3/PFE/static/", filename))
    #recuperer l'image
    noisy_img = img_as_float(io.imread("E:/S3/PFE/static/"+filename))
    #filtrer l'image
    BM3D_img = bm3d.bm3d(noisy_img, sigma_psd=1, stage_arg=bm3d.BM3DStages.ALL_STAGES)
    #calculer psnr                                                                                       
    noise_psnr = peak_signal_noise_ratio(BM3D_img, noisy_img)
    #enregistrer image filtrer
    nbr=str(random.randint(1, 10000))
    randomImageName = "image"+nbr+".jpg"
    plt.imsave("E:/S3/PFE/static/"+randomImageName, BM3D_img, cmap='gray')
    ####
    return render_template('result.html', message ="BM3D_Block_matching_and_3D_filtering" , noisy = str(noise_psnr), att = str(sigma), filename=randomImageName)
    #return str(noise_psnr)

@app.route("/TV_Total_variatient",methods=['POST'])
def TV_Total_variatient():
    
    #recuperer image 
    image = request.files["image"]
    #recuperer les parametre
    weight = float(request.values["weight"])
    selectOptionColor = str(request.values["selectOptionColor"])

    #chemin d'image
    filename = request.files["image"].filename
    #enregistrer image bruite
    image.save(os.path.join("E:/S3/PFE/static/", filename))
    #recuperer l'image
    noisy_img = img_as_float(io.imread("E:/S3/PFE/static/"+filename))
    #filtrer l'image
    TV_img = denoise_tv_chambolle(noisy_img, weight=0.1, multichannel=selectOptionColor)
    #calculer psnr                                                                                       
    noise_psnr = peak_signal_noise_ratio(TV_img, noisy_img)
    #enregistrer image filtrer
    nbr=str(random.randint(1, 10000))
    randomImageName = "image"+nbr+".jpg"
    plt.imsave("E:/S3/PFE/static/"+randomImageName, TV_img, cmap='gray')
    ####
    return render_template('result.html', message ="TV_Total_variatient" , noisy = str(noise_psnr), att = str(weight), filename=randomImageName)
    #return str(noise_psnr)

"""
@app.route('/html')
def upload_form():
    return render_template('index.html')


if __name__=="__main__":
    app.run()